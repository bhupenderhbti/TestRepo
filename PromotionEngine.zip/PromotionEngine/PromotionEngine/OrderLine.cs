﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine
{
   public class OrderLine
    {
        public int OrderLineId { get; set; }
        public Product product { get; set; }
        public int Qty { get; set; }
    }
}
