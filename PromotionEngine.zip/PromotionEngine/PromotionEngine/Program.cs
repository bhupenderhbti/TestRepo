﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PromotionEngine
{
    class Program
    {
        static void Main(string[] args)
        {
            //string 
            Console.WriteLine("Hello World!");
            Console.ReadLine();
            //Double p = ((3 * 50 - 130) / 3) * 100;
           // string[] promotion = { "3A", "2B", "C+D" };

            List<Product> products = new List<Product>
            { new Product() { Name = "A", Price = 50 },
             new Product() { Name = "B", Price = 30 },
             new Product() { Name = "C", Price = 20 },
             new Product() { Name = "D", Price = 15 }
            };

           
        
            
            Order order = new Order();
            order.OrderId = 1;
            order.OrderLines = new List<OrderLine>() {  new OrderLine() { product=products[0], OrderLineId=1,Qty=5},
            new OrderLine() { product= products[1], OrderLineId=2,Qty=5},
            new OrderLine() {  product=products[2], OrderLineId=1,Qty=2}

            };

            
          //  ManagePromotion managePromotion;
            float totalPrice = 0;
            order.OrderLines.ForEach(x =>
            {
                IPromotionEntity entity = GetPromotion(x.product);
                switch(entity.PromotionName)
                {
                    case "NItem":
                        totalPrice = totalPrice + new ManagePromotion(new NItemPromotion()).GetPrice(entity, x.Qty);
                        break;
                    case "Combined":
                        totalPrice = totalPrice + new ManagePromotion(new PrctgePromotion()).GetPrice(entity, x.Qty);
                        break;

                }
                
            });

            


        }

        public static Promotion GetPromotion(Product product)
        {
            Promotion promotion = GetPromotions().ToList().Where(x => x.Products.Where(y => y == product).FirstOrDefault().Name == product.Name).FirstOrDefault();
            return promotion;
        }

        public static List<Promotion> GetPromotions()
        {
            List<Promotion> promotions = new List<Promotion>()
            {
                new Promotion()
            {  PromotionName="Nitem",
                Products =new List<IProduct>()
                {
                    new Product() {  Name="A", Price=50}
                },
                 Price=130,
                  Qty=3
            },
                 new Promotion()
            {  PromotionName="Nitem",
                Products =new List<IProduct>()
                {
                    new Product() {  Name="B", Price=30}
                },
                 Price=45,
                  Qty=2
            },
                   new Promotion()
            {  PromotionName="Combined",
                Products =new List<IProduct>()
                {
                    new Product() {  Name="C", Price=20},
                     new Product() {  Name="D", Price=15}
                },
                 Price=30,
                  Qty=1
            }
            };

            return promotions;
        }


    }
}
