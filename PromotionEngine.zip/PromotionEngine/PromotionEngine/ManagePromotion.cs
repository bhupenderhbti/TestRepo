﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine
{
   public class ManagePromotion 
    {
        private IPromotion _promotion;
       public ManagePromotion(IPromotion promotion)
        {
            this._promotion = promotion;
        }
        
        public float GetPrice(IPromotionEntity entity,int qty)
        {
            return this._promotion.GetPromotionPrice(entity, qty);
        }
    }
}
