﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine
{
  public  class NItemPromotion :IPromotion
    {
        
        public float GetPromotionPrice(IPromotionEntity entity,int qty)
        {
            //logic to get multiply item and get the price
            return 0;
        }
    }
}
