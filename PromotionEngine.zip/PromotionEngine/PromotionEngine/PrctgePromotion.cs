﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine
{
  public  class PrctgePromotion :IPromotion
    {
      
       
        public float GetPromotionPrice(IPromotionEntity entity, int qty)
        {
            //logic to get  item by percentage
            return 0;
        }
    }
}
