﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine
{
    public class Order
    {
        public int OrderId { get; set; }
        public List<OrderLine> OrderLines {get;set;}
    }
}
