﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine
{
   public interface IProduct
    {
        string Name { get; set; }
        long Price { get; set; }
    }
}
