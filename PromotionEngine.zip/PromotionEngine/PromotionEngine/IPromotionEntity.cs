﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine
{
   public interface IPromotionEntity
    {
         string PromotionName { get; set; }
         List<IProduct> Products { get; set; }
         float Price { get; set; }
         float DPtge { get; set; }
         float CmbPrice { get; set; }
         int Qty { get; set; }

    }
}
