﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine
{
   public class Product :IProduct
    {
        public string Name { get; set; }
        public long Price { get; set; }
    }
}
