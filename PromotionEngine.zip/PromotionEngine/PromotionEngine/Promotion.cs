﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine
{
   public class Promotion :IPromotionEntity
    {
        public string PromotionName { get; set; }
        public List<IProduct> Products { get; set; }
        public float Price { get; set; }
        public float DPtge { get; set; }
        public float CmbPrice { get; set; }
        public int Qty { get; set; }
        



    }
}
