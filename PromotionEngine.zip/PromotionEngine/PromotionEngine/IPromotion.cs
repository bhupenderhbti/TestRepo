﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine
{
   public interface IPromotion
    {
        float GetPromotionPrice(IPromotionEntity entity,int qty);
        
    }
}
